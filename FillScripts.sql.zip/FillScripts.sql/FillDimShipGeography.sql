--------------------------------------
/* 
Fill Dim ShipGeography for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------
USE Northwind
GO
SELECT * 
FROM Orders
GO
USE NorthwindDW
GO
--Information extracted from Orders table
DROP TABLE IF EXISTS DimShipGeography
GO
CREATE TABLE DimShipGeography
(
	ShipGeographyKey INT IDENTITY(1,1) PRIMARY KEY NONCLUSTERED,
	ShipCountry NVARCHAR(15),
	ShipCity NVARCHAR(15),
	ETLTime DATETIME
)ON FGDim WITH (DATA_COMPRESSION=PAGE)
GO
CREATE UNIQUE CLUSTERED INDEX IX_Clustered_ShipCountry_ShipCity ON DimShipGeography(ShipCountry,ShipCity) 
	WITH (DATA_COMPRESSION=PAGE) ON FGDim
GO
--------------------------------------

USE NorthwindDW
TRUNCATE TABLE DimShipGeography

-----Insert Scripts
USE Northwind
GO
SELECT DISTINCT
     ShipCountry,
	 ShipCity ,
	 GETDATE() AS ETLTime
FROM Orders

USE NorthwindDW
GO
SELECT*
FROM DimShipGeography