﻿--------------------------------------
/* 
Fill Dim Shippers for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------
USE Northwind
GO
SELECT * FROM Shippers
GO
SP_HELP Shippers
GO
---Create table
USE Northwind
GO
SELECT * FROM Shippers
GO
CREATE TABLE DimShipper
(
	ShipperKey INT PRIMARY KEY ,
	ShipperIDBK INT,
	CompanyName NVARCHAR(40),
	ETLTime DATETIME
) ON FGDim WITH (DATA_COMPRESSION=PAGE)
GO
--------------------------------------
USE NorthwindDW
TRUNCATE TABLE DimShipper
-----Insert Scripts
USE Northwind
GO
SELECT
	ShipperID AS ShipperKey,
	ShipperID AS ShipperIDBK ,
	CompanyName,
	GETDATE() AS ETLTime
FROM Shippers

USE NorthwindDW
GO
SELECT*
FROM DimShipper