﻿--------------------------------------
/* 
Fill FactOrder for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------
USE Northwind
GO
SELECT * FROM Orders WHERE OrderID=10248
SELECT * FROM [Order Details]  WHERE OrderID=10248
GO
SP_HELP Orders
SP_HELP [Order Details] 
GO

USE NorthwindDW
GO
DROP TABLE IF EXISTS FactOrder
GO
CREATE TABLE FactOrder
(
	OrderKey INT IDENTITY(1,1) PRIMARY KEY NONCLUSTERED,
	OrderIDBK INT,
	CustomerKey INT,
	EmployeeKey INT,
	OrderDateKey INT,
	RequiredDateKey INT ,
	ShippedDateKey INT ,
	ShipperKey INT,
	ShipGeographyKey INT,
	ProductKey INT ,
	ShipPostalCode NVARCHAR(10),
	ShipAddress NVARCHAR(60),
	Freight MONEY,
	UnitPrice MONEY,
	Quantity SMALLINT,
	Discount DECIMAL(5,2),
	ETLTime DATETIME
)ON FGFact WITH (DATA_COMPRESSION=PAGE)
GO
CREATE CLUSTERED INDEX IX_Clustered_OrderIDBK ON FactOrder(OrderIDBK) 
	WITH (DATA_COMPRESSION=PAGE) ON FGFact
GO
--------------------------------------
USE NorthwindDW
TRUNCATE TABLE FactOrder
-----Insert Scripts
USE Northwind
GO
SELECT
     Orders.OrderID AS OrderIDBK,
	 Orders.CustomerID,
	 Orders.EmployeeID AS EmployeeKey,
	 CAST(FORMAT (Orders.OrderDate,'yyyyMMdd') AS INT)AS OrderDateKey,
	 CAST(FORMAT (Orders.RequiredDate,'yyyyMMdd') AS INT)AS RequiredDateKey,
	 CAST(FORMAT (Orders.ShippedDate,'yyyyMMdd') AS INT)AS ShippedDateKey,
	 Orders.ShipVia AS ShipperKey,
	 Orders.ShipCountry,
	 Orders.ShipCity,
	 [Order Details].ProductID AS ProductKey,
	 Orders.ShipPostalCode,
	 Orders.ShipAddress,
	 Orders.Freight,
	 [Order Details].UnitPrice,
	 [Order Details].Quantity,
	 [Order Details].Discount,
	 GETDATE() AS ETLTime
FROM Orders
INNER JOIN [Order Details] ON 
Orders.OrderID=[Order Details].OrderID

USE NorthwindDW
SELECT *
FROM FactOrder
