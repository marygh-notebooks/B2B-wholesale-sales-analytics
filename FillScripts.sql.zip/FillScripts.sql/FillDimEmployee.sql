﻿--------------------------------------
/* 
Fill Dim Employee for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------
USE Northwind
GO
SELECT * FROM Employees
GO
SP_HELP Employees
GO
----create DimEmployee Table
USE NorthwindDW
GO
CREATE TABLE DimEmployee
(
	EmployeeKey INT PRIMARY KEY,
	EmployeeIDBK INT,
	LastName NVARCHAR(20),
	FirstName NVARCHAR(10),
	BirthDate DATE, 
	HireDate DATE,
	City NVARCHAR(15),
	Region NVARCHAR(15),
	EmployeeKeyReportsTo INT,
	ETLTime DATETIME
)ON FGDim WITH (DATA_COMPRESSION=PAGE)
GO
--------------------------------------------------------------------
USE NorthwindDW
GO
TRUNCATE TABLE DimEmployee

----Insert Scripts
USE Northwind
GO

SELECT  
    EmployeeID AS EmployeeKey,
	EmployeeID AS EmployeeIDBK,
	LastName AS LastName ,
	FirstName AS FirstName ,
	BirthDate AS BirthDate , 
	HireDate AS HireDate ,
	City AS City ,
	Region AS Region ,
	ReportsTo AS EmployeeKeyReportsTo,
	GETDATE() AS ETLTime 
FROM Employees
GO
USE NorthwindDW
GO
SELECT*
FROM DimEmployee