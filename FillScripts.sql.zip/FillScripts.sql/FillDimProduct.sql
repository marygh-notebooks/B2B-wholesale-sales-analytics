﻿--------------------------------------
/* 
Fill Dim Product for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------

---Create table
USE NorthwindDW
GO
DROP TABLE IF EXISTS DimProduct
GO
CREATE TABLE DimProduct
(
	ProductKey INT PRIMARY KEY,
	ProductIDBK INT,
	ProductName NVARCHAR(40),
	SupplierID INT,
	SupplierCompanyName NVARCHAR(40),
	SupplierCity  NVARCHAR(15),
	SupplierRegion NVARCHAR(15),
	SupplierCountry NVARCHAR(15),
	CategoryID INT,
	CategoryName NVARCHAR(15),
	ETLTime DATETIME
)ON FGDim WITH (DATA_COMPRESSION=PAGE)
GO
---------------------------------------------
USE NorthwindDW
GO
TRUNCATE TABLE DimProduct

---------------------------------------------
---Insert Script
USE Northwind
GO
SELECT
    Products.ProductID AS ProductKey ,
	Products.ProductID AS ProductIDBK ,
	Products.ProductName ,
	Suppliers.SupplierID ,
	Suppliers.CompanyName AS  SupplierCompanyName ,
	Suppliers.City AS SupplierCity  ,
	Suppliers.Region AS SupplierRegion ,
	Suppliers.Country AS SupplierCountry ,
	Categories.CategoryID AS CategoryID ,
	Categories.CategoryName AS CategoryName,
	GETDATE() AS ETLTime 
FROM Products
INNER JOIN Suppliers
ON Products.SupplierID= Suppliers.SupplierID
INNER JOIN Categories
ON Products.CategoryID=Categories.CategoryID

---------------------------------------------

/*USE NorthwindDW
GO
SELECT*
FROM DimProduct
*/


