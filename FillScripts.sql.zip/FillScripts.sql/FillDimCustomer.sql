﻿--------------------------------------
/* 
Fill Dim Customers for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------
USE Northwind
GO
SELECT * FROM Customers
GO
SP_HELP Customers
GO
-----Create DimCustomer
USE NorthwindDW
GO
DROP TABLE IF EXISTS DimCustomer
GO
CREATE TABLE DimCustomer
(
	CustomerKey INT IDENTITY(1,1) PRIMARY KEY NONCLUSTERED,
	CustomerIDBK NCHAR(5),
	CompanyName NVARCHAR(40),
	City  NVARCHAR(15),
	Region  NVARCHAR(15),
	Country  NVARCHAR(15),
	ETLTime DATETIME ,
)ON FGDim WITH (DATA_COMPRESSION=PAGE)
GO
CREATE UNIQUE CLUSTERED INDEX IX_Clustered_CustomerIDBK ON DimCustomer(CustomerIDBK) 
	WITH (DATA_COMPRESSION=PAGE) ON FGDim
GO

--------------------------------------
USE NorthwindDW
TRUNCATE TABLE DimCustomer
-----Insert Scripts
USE Northwind
GO

SELECT
	CustomerID AS CustomerIDBK ,
	CompanyName ,
	City  ,
	Region  ,
	Country  ,
	GETDATE() AS ETLTime 
FROM Customers

USE NorthwindDW
GO
SELECT *
FROM DimCustomer