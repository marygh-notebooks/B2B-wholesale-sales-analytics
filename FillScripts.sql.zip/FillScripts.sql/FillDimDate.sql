﻿--------------------------------------
/* 
Fill Dim Date for Northwind Project
Created By: Maryam Ghamarian
   */
--------------------------------------
USE NorthwindDW
GO
SELECT MIN(OrderDateKey),MAX(OrderDateKey) 
FROM FactOrder
GO

CREATE TABLE DimDate (
    DateKey INT PRIMARY KEY,
    FullDate DATE,
    Day INT,
    Month INT,
    MonthName VARCHAR(20),
    Quarter INT,
    Year INT,
    WeekdayName VARCHAR(20),
    IsWeekend BIT
);

DECLARE @Date DATE = '1996-01-01';

WHILE @Date <= '1998-12-31'
BEGIN
    INSERT INTO DimDate
    VALUES (
        CONVERT(INT, FORMAT(@Date, 'yyyyMMdd')),
        @Date,
        DAY(@Date),
        MONTH(@Date),
        DATENAME(MONTH, @Date),
        DATEPART(QUARTER, @Date),
        YEAR(@Date),
        DATENAME(WEEKDAY, @Date),
        CASE WHEN DATENAME(WEEKDAY, @Date) IN ('Saturday', 'Sunday') THEN 1 ELSE 0 END
    );
    SET @Date = DATEADD(DAY, 1, @Date);
END;